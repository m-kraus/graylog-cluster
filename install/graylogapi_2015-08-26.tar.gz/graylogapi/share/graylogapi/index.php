<?php
require 'vendor/autoload.php';

# set timezone for sorting purposes
date_default_timezone_set('UTC');

$conf = array(
	"time"		=> $_SERVER["REQUEST_TIME_FLOAT"],
	"site"		=> $_SERVER["OMD_ROOT"],
	"debug"		=> true,
	"debugpath"	=> "/tmp/",
);

$app = new \Slim\Slim();


#
# debug
#
if ( $conf["debug"] == true ) {
    $app->get('/:host/:svc', function ($host, $service) use ($app, $conf) {
        # print values
        echo $conf["time"] . "QUERY $host , $service\n";
    
    	# save complete request
    	$req = print_r($app->request, true);
    	file_put_contents($conf["debugpath"].$conf["time"].".debug", $req);
    });
}

#
# POST
#
$app->post('/:host/:svc/:state', function ($host, $service, $state) use ($app, $conf) {

    #
    # apikey 
    #
    #TODO apikey handling
    $apikey = $app->request()->params('apikey');
    $apikeys = file($conf["site"].'/etc/graylogapi/apikeys', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if ( !in_array($apikey, $apikeys) ) {
	$app->halt(403, 'API authorization failed');
    }

    #
    # debug
    #
    if ( $conf["debug"] == true ) {
	# save complete request
	$req = print_r($app->request, true);
	file_put_contents($conf["debugpath"].$conf["time"].".debug", $req);
    }

    #
    # prepare nagios return codes
    # 
    $ret = array(
        0 => "OK",
        1 => "WARNING",
        2 => "CRITICAL",
        3 => "UNKNOWN",
    );
     
    #
    # set all unknown states
    #
    if ( ! (0 <= $state) && ($state <= 2) ) {
        $state = 3;
    }
    
    #
    # request body is json, get messages
    #
    $data = json_decode($app->request->getBody(), true);
    $messages = $data["check_result"]["matching_messages"];

    #
    # time sort on timestamp field
    #
    $myDateSort = function($obj1, $obj2) {
        $date1 = strtotime($obj1["timestamp"]);
        $date2 = strtotime($obj2["timestamp"]);
        return $date1 - $date2;
    };
    usort($messages, $myDateSort);

    #
    # init livestatus client
    #
    $livestatusoptions = array(
        'socketType' => 'unix',
        'socketPath' => $conf["site"].'/tmp/run/live',
    );

    $app->client = new \Nagios\Livestatus\Client($livestatusoptions);

    #
    # loop over messages
    #
    foreach($messages as $message) {
        $output = $ret[$state] . " ";
        $output .= $message["source"] . ": ";
        $output .= "( " . $message["timestamp"] . " ) ";
        $output .= $message["message"] . "\n";
        echo "MSG,\n";
        echo $output;

        #
        # send every message via livestatus
        #
        $app->client->command(array(
            'PROCESS_SERVICE_CHECK_RESULT',
            $host,
            $service,
            $state,
            $output, 
        ));
    }
});
$app->run();

?>
